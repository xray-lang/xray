/*
 * xray - Lightweight typed scripting with native concurrency
 * https://www.xray-lang.org
 * Copyright (c) 2026 Xinglei Xu <xingleixu@gmail.com>
 * Licensed under the MIT License
 *
 * xxir_interface_members.h - Exact inherited requirement consistency
 *
 * KEY CONCEPT:
 *   One application expansion kernel retains original obligations and compares
 *   method-local binders after lifting them beyond the authentic ambient scope.
 */
#ifndef XXIR_INTERFACE_MEMBERS_H
#define XXIR_INTERFACE_MEMBERS_H
#include "xxir_interface.h"

typedef struct XrXirInterfaceClosure XrXirInterfaceClosure;
typedef struct XrXirInterfaceRequirement {
    uint32_t application, origin_interface, member;
    XrXirType signature;
    XrXirLiteral name;
    uint32_t receiver;
    uint32_t own_parameter_count;
    const XrXirConstraint *constraints;
} XrXirInterfaceRequirement;

/* Inputs require structural and acyclic validation in one parameter context.
 * Closures borrow immutable input types, nominal metadata and declaration names;
 * they must be freed before those inputs. They own application arrays and newly
 * materialized descriptors. Scratch IDs belong exclusively to closure_types and
 * must not enter persistent XIR; consumers must reify into their own type arena.
 * Method own parameters are alpha-lifted to ambient_parameter_count + j.
 * Ambient count is the authentic caller count, never the largest used span.
 * Output slots must be empty. Failures publish no closure and never refund
 * charged work or cumulative allocation. */
typedef struct XrXirInterfaceClosureRequest {
    const XrXirTypes *source_types, *actual_types;
    const XrXirInterfaceApplication *roots;
    uint32_t root_count;
    const XrXirType *arguments;
    uint32_t argument_count;
    uint32_t ambient_parameter_count;
} XrXirInterfaceClosureRequest;
typedef struct XrXirInterfaceClosureRoots {
    const XrXirInterfaceTable *table;
    const XrXirTypes *types;
    const XrXirInterfaceApplication *roots;
    uint32_t root_count, ambient_parameter_count;
} XrXirInterfaceClosureRoots;
/* Root expressions and the interface catalog belong to source_types. The
 * complete substitution belongs to actual_types, whose pool is borrowed. */
XR_FUNC XrXirStatus xr_xir_compile_interface_closure_substitute(const XrXirCompileContext *compile_context, const XrXirInterfaceClosureRequest *request, XrXirInterfaceClosure **output);
XR_FUNC XrXirStatus xr_xir_compile_interface_closure_build(const XrXirCompileContext *compile_context, const XrXirInterfaceClosureRoots *request, XrXirInterfaceClosure **output);
XR_FUNC const XrXirTypes *xr_xir_interface_closure_types(const XrXirInterfaceClosure *closure);
XR_FUNC uint32_t xr_xir_interface_closure_application_count(const XrXirInterfaceClosure *closure);
XR_FUNC const XrXirInterfaceApplication *xr_xir_interface_closure_application(
    const XrXirInterfaceClosure *closure, uint32_t index);
XR_FUNC uint32_t xr_xir_interface_closure_requirement_count(const XrXirInterfaceClosure *closure);
XR_FUNC const XrXirInterfaceRequirement *xr_xir_interface_closure_requirement(
    const XrXirInterfaceClosure *closure, uint32_t index);
XR_FUNC void xr_xir_compile_interface_closure_free(XrXirInterfaceClosure *closure);

/* Requires structurally verified descriptors and acyclic interface declarations.
 * Checks every declaration, including unused ones. Original declarations retain
 * all distinct obligations; temporary application deduplication loses no identity.
 * Failures publish no partial result and retain completed work and cumulative
 * allocation charges. */
XR_FUNC XrXirStatus xr_xir_compile_interfaces_verify_members_verified(const XrXirCompileContext *compile_context, const XrXirInterfaceTable *table, const XrXirTypes *types);
#endif // XXIR_INTERFACE_MEMBERS_H
