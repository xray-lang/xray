/*
 * xray - Lightweight typed scripting with native concurrency
 * https://www.xray-lang.org
 * Copyright (c) 2026 Xinglei Xu <xingleixu@gmail.com>
 * Licensed under the MIT License
 *
 * xxir_constraint_proof.h - Explicit declaration environments and substitutions
 *
 * KEY CONCEPT:
 *   Required parameters are substituted as a complete vector before entailment.
 */
#ifndef XXIR_CONSTRAINT_PROOF_H
#define XXIR_CONSTRAINT_PROOF_H
#include "xxir_interface.h"

typedef enum XrXirContextKind {
    XR_XIR_CONTEXT_FUNCTION, XR_XIR_CONTEXT_NOMINAL, XR_XIR_CONTEXT_INTERFACE, XR_XIR_CONTEXT_CLOSED,
    XR_XIR_CONTEXT_INTERFACE_METHOD, XR_XIR_CONTEXT_CONFORMANCE_METHOD
} XrXirContextKind;
/* Old declaration kinds require member == 0. INTERFACE_METHOD selects an
 * interface declaration and direct member. CONFORMANCE_METHOD selects an
 * implementation record and binding, is valid only for ProofContext.owner,
 * and requires previously admitted implementation shape/signature priors.
 * Its facts are nominal constraints plus the original requirement own bounds;
 * implementation function constraints are never imported as facts. */
typedef struct XrXirDeclarationContext {
    XrXirContextKind kind;
    uint32_t declaration;
    uint32_t member;
} XrXirDeclarationContext;
typedef struct XrXirProofContext {
    const XrXirModule *module;
    XrXirDeclarationContext owner;
} XrXirProofContext;
typedef struct XrXirConstraintUse {
    const XrXirModule *declaration_module;
    XrXirDeclarationContext declaration;
    uint32_t parameter;
    const XrXirType *arguments;
    uint32_t argument_count;
} XrXirConstraintUse;
/* Derives facts and requirements only from their authentic declaration records.
 * Descriptor/declaration shapes and implementation signature priors must have
 * been admitted. Semantic failures consume budget; no pending obligation grants
 * success. Neither query admits a function body or naming access by itself. */
XR_FUNC XrXirStatus xr_xir_compile_constraints_prove(const XrXirCompileContext *compile_context, const XrXirProofContext *context, const XrXirConstraintUse *use);

/* Structural admission grants no proof authority. */
XR_FUNC XrXirStatus xr_xir_compile_constraint_structure(const XrXirCompileContext *compile_context, const XrXirTypes *types, XrXirConstraint constraint, uint32_t parameter_count);
XR_FUNC XrXirStatus xr_xir_compile_type_use_verify(const XrXirCompileContext *compile_context, const XrXirProofContext *context, XrXirType type);
/* Intrinsic ordinary-value admission, not a user-visible marker. Parameters
 * derive copy/save obligations from this exact binder. This does not promise
 * any particular closed physical class carrier, layout or execution authority.
 * Unit and internal Cell are outside the current ordinary-argument IR domain;
 * no resource/view carrier is represented by this API. */
XR_FUNC XrXirStatus xr_xir_compile_type_storage_prove(const XrXirCompileContext *compile_context, const XrXirProofContext *context, XrXirType type);
XR_FUNC XrXirStatus xr_xir_compile_type_markers_prove(const XrXirCompileContext *compile_context, const XrXirProofContext *context, XrXirType type, uint32_t markers);
XR_FUNC XrXirStatus xr_xir_compile_context_constraints_verify(const XrXirCompileContext *compile_context, const XrXirProofContext *context);
/* Catalog admission reads no initializer bodies or inferred instance slots. */
XR_FUNC XrXirStatus xr_xir_compile_declaration_constraints_verify(const XrXirCompileContext *compile_context, const XrXirModule *module);
/* Complete signature structure is a prior of the full module pass; all slots
 * and cross-module Sendable obligations are checked even without catalogs. */
XR_FUNC XrXirStatus xr_xir_compile_module_constraints_verify(const XrXirCompileContext *compile_context, const XrXirModule *module);
/* Arguments and subject belong to context.module; identities and explicit
 * implementation rules belong to declaration_module. Cross-pool nominal
 * identities must already have authenticated provenance. */
XR_FUNC XrXirStatus xr_xir_compile_interface_prove(const XrXirCompileContext *compile_context, const XrXirProofContext *context, const XrXirModule *declaration_module, XrXirType subject, XrXirInterfaceApplication application);
#endif // XXIR_CONSTRAINT_PROOF_H
